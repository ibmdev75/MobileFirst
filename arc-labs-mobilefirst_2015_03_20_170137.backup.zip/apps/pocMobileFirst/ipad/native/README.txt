This folder contains an iOS project based on a IBM MobileFirst Platform template project.   
The contents of this project are:
* Classes       - Project classes
* CordovaLib    - Cordova implementation and plug-ins
* WorklightSDK  - Objective-C API classes for accessing the IBM MobileFirst Platform Server
* www           - Contains the HTML, CSS and JavaScript sources for the project (including the JavaScript API for accessing the IBM MobileFirst Platform Server)
